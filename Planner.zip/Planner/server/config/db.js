module.exports =
{
    "URI":"mongodb://localhost/Assignment3"
}