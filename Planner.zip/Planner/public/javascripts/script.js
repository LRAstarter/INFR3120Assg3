document.getElementById("pokeball").addEventListener("click", openBall);

function openBall() {

    location.replace("./pokemon-list")

}
